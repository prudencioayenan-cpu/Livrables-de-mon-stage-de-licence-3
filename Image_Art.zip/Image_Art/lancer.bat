@echo off
cd /d C:\Users\ADMIN\Desktop\PrudencioAyenan\Image_Art
start python Image_Art.py
timeout /t 2 /nobreak
start https://127.0.0.1:5000
